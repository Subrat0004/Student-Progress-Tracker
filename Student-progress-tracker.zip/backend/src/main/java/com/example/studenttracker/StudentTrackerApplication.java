package com.example.studenttracker;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class StudentTrackerApplication {
  public static void main(String[] args) {
    SpringApplication.run(StudentTrackerApplication.class, args);
  }
}
